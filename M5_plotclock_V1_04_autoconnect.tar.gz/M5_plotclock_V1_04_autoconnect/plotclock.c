/***************************************************
  This is an example for our Adafruit 16-channel PWM & Servo driver
  Servo test - this will drive 8 servos, one after the other on the
  first 3 pins of the PCA9685
  https://github.com/adafruit/Adafruit-PWM-Servo-Driver-Library
****************************************************/
/***************************************************
 Plotclock
 cc - by Johannes Heberlein 2014
 v 1.01
 thingiverse.com/joo   wiki.fablab-nuernberg.de
 units: mm; microseconds; radians
 origin: bottom left of drawing surface
 time library see http://playground.arduino.cc/Code/time 
****************************************************/
#include "pca9685.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <math.h>

#define PIN_BASE 300
#define MAX_PWM 4096
#define HERTZ 60

// delete or mark the next line as comment when done with calibration  
//#define CALIBRATION

// When in calibration mode, adjust the following factor until the servos move exactly 90 degrees
#define SERVOFAKTOR 550  // default = 620

// Zero-position of left and right servo
// When in calibration mode, adjust the NULL-values so that the servo arms are at all times parallel
// either to the X or Y axis
#define SERVOLEFTNULL 1800  // default = 1900 preouis value 1700
#define SERVORIGHTNULL 950  // defaule = 984 previous value:1000

#define SERVOPINLIFT  0
#define SERVOPINLEFT  1
#define SERVOPINRIGHT 2

// lift positions of lifting servo
#define LIFT0 1650 // on drawing surface
#define LIFT1 1550  // between numbers
#define LIFT2 1350  // going towards sweeper

// speed of liftimg arm, higher is slower
#define LIFTSPEED 500  // usec 1500

#define LINESPEED 15    // msec 15
#define CURVESPEED 10    // msec 10
#define CHARINTERVAL 20    // msec 20

// length of arms
#define L1 35   // default = 35
#define L2 57 // default = 55.1 measure = 44.5
#define L3 13 // default = 13.2 measure = 14.5

// origin points of left and right servo 
#define O1X 22
#define O1Y -23
#define O2X 47
#define O2Y -23


void setServoPulse(int n, double pulse_us);
void drawFromTo(double pX, double pY, double qX, double qY);
void number(float bx, float by, int num, float scale);
void lift(char lift);
void bogenUZS(float bx, float by, float radius, int start, int ende, float sqee);
void bogenGZS(float bx, float by, float radius, int start, int ende, float sqee);
void drawTo(double pX, double pY);
void set_XY(double Tx, double Ty);
void sigint_handler(int sig);
void setup(void);
void loop(void);

int servoLift = LIFT2;

volatile double lastX = 75;
volatile double lastY = 47.5;

int last_hours = 0;
int last_min = 0;

double currentX;
double currentY;

/*************************************************** 
 you can use this function if you'd like to set the pulse length in microsecond
***************************************************/
void setServoPulse(int servonum, double pulse_us){
  double pulselength;
  
  pulselength = 1000000;   // 1,000,000 us per second
  pulselength /= HERTZ;   // 60 Hz
//  Serial.print(pulselength); Serial.println(" us per period"); 
  pulselength /= MAX_PWM;  // 12 bits of resolution
//  Serial.print(pulselength); Serial.println(" us per bit"); 
  pulse_us /= pulselength;
//  Serial.println(pulse_us);

//  pwm.setPWM(n, 0, pulse_us);
  pwmWrite(PIN_BASE + servonum, pulse_us);
}

/*************************************************** 
 Draw Line from p to q
***************************************************/
void drawFromTo(double pX, double pY, double qX, double qY){
  double dx, dy;
  double absx, absy;
  int i;
  int accuracy = 1;
  int loop;

  dx = qX - pX;
  dy = qY - pY;

  absx = abs(dx / accuracy);
  absy = abs(dy / accuracy);

  if(absx >= absy){
    loop = absx;
  }else{
    loop = absy;
  }

  for (i = 0; i <= loop; i++) {
    drawTo(pX + ((dx / loop) * i), pY + ((dy / loop) * i));
    delay(LINESPEED);
  }
  drawTo(qX, qY);
}

/*************************************************** 
 Writing numeral with bx by being the bottom left originpoint. Scale 1 equals a 20 mm high font.
 The structure follows this principle: move to first startpoint of the numeral, lift down, draw numeral, lift up
***************************************************/
void number(float bx, float by, int num, float scale){
  float bxx;
  float byy;
  float radius;
  int start;
  int ende;
  float sqee;

  double nextX;
  double nextY;

  switch (num){
  case 0:
    drawTo(bx + 12 * scale, by + 6 * scale);
    lift(0);
    bxx = bx + 7 * scale;
    byy = by + 10 * scale;
    radius = 10 * scale;
    start = -0.8;
    ende = 6.7;
    sqee = 0.5;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 12 * scale, by + 6 * scale, nextX, nextY);
    bogenGZS(bx + 7 * scale, by + 10 * scale, 10 * scale, -0.8, 6.7, 0.5);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 1:
    drawTo(bx + 3 * scale, by + 15 * scale);
    lift(0);
    drawFromTo(bx + 3 * scale, by + 15 * scale, bx + 10 * scale, by + 20 * scale);
    drawFromTo(bx + 10 * scale, by + 20 * scale, bx + 10 * scale, by + 0 * scale);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 2:
    drawTo(bx + 2 * scale, by + 12 * scale);
    lift(0);
    bxx = bx + 8 * scale;
    byy = by + 14 * scale;
    radius = 6 * scale;
    start = 3;
    ende = -0.8;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 2 * scale, by + 12 * scale, nextX, nextY);
    bogenUZS(bx + 8 * scale, by + 14 * scale, 6 * scale, 3, -0.8, 1);
    drawFromTo(currentX, currentY, bx + 1 * scale, by + 0 * scale);
    drawFromTo( bx + 1 * scale, by + 0 * scale, bx + 12 * scale, by + 0 * scale);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 3:
    drawTo(bx + 2 * scale, by + 17 * scale);
    lift(0);
    bxx = bx + 5 * scale;
    byy = by + 15 * scale;
    radius = 5 * scale;
    start = 3;
    ende = -2;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 2 * scale, by + 17 * scale, nextX, nextY);
    bogenUZS(bx + 5 * scale, by + 15 * scale, 5 * scale, 3, -2, 1);

    bxx = bx + 5 * scale;
    byy = by + 5 * scale;
    radius = 5 * scale;
    start = 1.57;
    ende = -3;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;
    
    drawFromTo(currentX, currentY, nextX, nextY);
    bogenUZS(bx + 5 * scale, by + 5 * scale, 5 * scale, 1.57, -3, 1);
    delay(CHARINTERVAL);
    lift(1);
    break;
  case 4:
    drawTo(bx + 10 * scale, by + 0 * scale);
    lift(0);
    drawFromTo(bx + 10 * scale, by + 0 * scale, bx + 10 * scale, by + 20 * scale);
    drawFromTo(bx + 10 * scale, by + 20 * scale, bx + 2 * scale, by + 6 * scale);
    drawFromTo(bx + 2 * scale, by + 6 * scale, bx + 12 * scale, by + 6 * scale);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 5:
    drawTo(bx + 2 * scale, by + 5 * scale);
    lift(0);
    bxx = bx + 5 * scale;
    byy = by + 6 * scale;
    radius = 6 * scale;
    start = -2.5;
    ende = 2;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 2 * scale, by + 5 * scale, nextX, nextY);
    bogenGZS(bx + 5 * scale, by + 6 * scale, 6 * scale, -2.5, 2, 1);
    drawFromTo(currentX, currentY, bx + 5 * scale, by + 20 * scale);
    drawFromTo(bx + 5 * scale, by + 20 * scale, bx + 12 * scale, by + 20 * scale);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 6:
    drawTo(bx + 2 * scale, by + 10 * scale);
    lift(0);
    bxx = bx + 7 * scale;
    byy = by + 6 * scale;
    radius = 6 * scale;
    start = 2;
    ende = -4.4;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 2 * scale, by + 10 * scale, nextX, nextY);
    bogenUZS(bx + 7 * scale, by + 6 * scale, 6 * scale, 2, -4.4, 1);
    drawFromTo(currentX, currentY, bx + 11 * scale, by + 20 * scale);
    delay(CHARINTERVAL);
    lift(1);
    break;
  case 7:
    drawTo(bx + 2 * scale, by + 20 * scale);
    lift(0);
    drawFromTo(bx + 2 * scale, by + 20 * scale, bx + 12 * scale, by + 20 * scale);
    drawFromTo(bx + 12 * scale, by + 20 * scale, bx + 2 * scale, by + 0);
    lift(1);
    delay(CHARINTERVAL);
    break;
  case 8:
    drawTo(bx + 5 * scale, by + 10 * scale);
    lift(0);
    bxx = bx + 5 * scale;
    byy = by + 15 * scale;
    radius = 5 * scale;
    start = 4.7;
    ende = -1.6;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(bx + 5 * scale, by + 10 * scale, nextX, nextY);
    bogenUZS(bx + 5 * scale, by + 15 * scale, 5 * scale, 4.7, -1.6, 1);

    bxx = bx + 5 * scale;
    byy = by + 5 * scale;
    radius = 5 * scale;
    start = -4.7;
    ende = 2;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;

    drawFromTo(currentX, currentY, nextX, nextY);
    bogenGZS(bx + 5 * scale, by + 5 * scale, 5 * scale, -4.7, 2, 1);
    lift(1);
    delay(CHARINTERVAL);
    break;

  case 9:
    drawTo(bx + 9 * scale, by + 11 * scale);
    lift(0);
    bxx = bx + 7 * scale;
    byy = by + 15 * scale;
    radius = 5 * scale;
    start = 4;
    ende = -0.5;
    sqee = 1;
    nextX = sqee * radius * cos(start) + bxx;
    nextY = radius * sin(start) + byy;
   
    drawFromTo(bx + 9 * scale, by + 11 * scale, nextX, nextY);
    bogenUZS(bx + 7 * scale, by + 15 * scale, 5 * scale, 4, -0.5, 1);
    drawFromTo(currentX, currentY, bx + 5 * scale, by + 0);
   lift(1);
   delay(CHARINTERVAL);
    break;

  case 111:

    lift(0);
    drawFromTo(70, 46, 65, 43);
    drawFromTo(65, 43, 65, 49);
    drawFromTo(65, 49, 5, 49);

    drawFromTo(5, 49, 5, 45);
    drawFromTo(5, 45, 65, 45);
    drawFromTo(65, 45, 65, 40);
    drawFromTo(65, 40, 5, 40);

    drawFromTo(5, 40, 5, 35);
    drawFromTo(5, 35, 64, 35);
    drawFromTo(65, 35, 65, 30);
    drawFromTo(65, 30, 5, 30);

    drawFromTo(5, 30, 5, 25);
    drawFromTo(5, 25, 65, 25);
    drawFromTo(65, 25, 65, 20);
    drawFromTo(65, 20, 5, 20);

    drawFromTo(5, 20, 60, 44);
    drawFromTo(60, 44, 75.2, 47);

    lift(2);
    delay(CHARINTERVAL);

    break;

  case 11:
    drawTo(bx + 5 * scale, by + 15 * scale);
    lift(0);
    bogenGZS(bx + 5 * scale, by + 15 * scale, 0.1 * scale, 1, -1, 1);
    lift(1);
    delay(CHARINTERVAL);
    drawTo(bx + 5 * scale, by + 5 * scale);
    lift(0);
    bogenGZS(bx + 5 * scale, by + 5 * scale, 0.1 * scale, 1, -1, 1);
    lift(1);
    delay(CHARINTERVAL);
    break;
  }
}

void lift(char lift){
  switch (lift) {
  case 0: // on drawing surface
    if (servoLift >= LIFT0) {
      while (servoLift >= LIFT0){
        servoLift--;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }else{
      while (servoLift <= LIFT0){
        servoLift++;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }
    break;

  case 1: // between numbers
    if (servoLift >= LIFT1){
      while (servoLift >= LIFT1){
        servoLift--;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }else{
      while (servoLift <= LIFT1){
        servoLift++;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }
    break;

  case 2: // going towards sweeper
    if (servoLift >= LIFT2){
      while (servoLift >= LIFT2){
        servoLift--;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }else{
      while (servoLift <= LIFT2){
        servoLift++;
        setServoPulse(SERVOPINLIFT, (double)servoLift);
        delayMicroseconds(LIFTSPEED);
      }
    }
    break;
  }
}

void bogenUZS(float bx, float by, float radius, int start, int ende, float sqee){
  float inkr = -0.05;
  float count = 0;
  do{
    currentX = sqee * radius * cos(start + count) + bx;
    currentY = radius * sin(start + count) + by;
    drawTo(currentX, currentY);
    count += inkr;
    delay(CURVESPEED);
  }
  while ((start + count) > ende);
}

void bogenGZS(float bx, float by, float radius, int start, int ende, float sqee){
  float inkr = 0.05;
  float count = 0;
  do{
    currentX = sqee * radius * cos(start + count) + bx;
    currentY = radius * sin(start + count) + by;
    drawTo(currentX, currentY);
    count += inkr;
    delay(CURVESPEED);
  }
  while ((start + count) <= ende);
}

void drawTo(double pX, double pY){
  double dx, dy, c;
  int i;
  // dx dy of new point
  dx = pX - lastX;
  dy = pY - lastY;
  //path lenght in mm, times 4 equals 4 steps per mm
  c = floor(4 * sqrt(dx * dx + dy * dy));

  if (c < 1){
    c = 1;
  }

  for (i = 0; i <= c; i++){
    // draw line point by point
    set_XY(lastX + (i * dx / c), lastY + (i * dy / c));
  }
  lastX = pX;
  lastY = pY;
}

double return_angle(double a, double b, double c){
  // cosine rule for angle between c and a
  return acos((a * a + c * c - b * b) / (2 * a * c));
}

void set_XY(double Tx, double Ty){
  delay(1);
  double dx, dy, c, a1, a2, Hx, Hy;
  // calculate triangle between pen, servoLeft and arm joint
  // cartesian dx/dy
  dx = Tx - O1X;
  dy = Ty - O1Y;
  // polar lemgth (c) and angle (a1)
  c = sqrt(dx * dx + dy * dy); // 
  a1 = atan2(dy, dx); //
  a2 = return_angle(L1, L2, c);

  setServoPulse(SERVOPINLEFT, (double)(floor(((a2 + a1 - M_PI) * SERVOFAKTOR) + SERVOLEFTNULL)));

  // calculate joinr arm point for triangle of the right servo arm
  a2 = return_angle(L2, L1, c);
  Hx = Tx + L3 * cos((a1 - a2 + 0.621) + M_PI); //36,5°
  Hy = Ty + L3 * sin((a1 - a2 + 0.621) + M_PI);
  // calculate triangle between pen joint, servoRight and arm joint
  dx = Hx - O2X;
  dy = Hy - O2Y;

  c = sqrt(dx * dx + dy * dy);
  a1 = atan2(dy, dx);
  a2 = return_angle(L1, (L2 - L3), c);

  setServoPulse(SERVOPINRIGHT, (double)(floor(((a1 - a2) * SERVOFAKTOR) + SERVORIGHTNULL)));
}




// SigInt handler

void sigint_handler(int sig)
{

   	setServoPulse(SERVOPINLIFT, 0);
   	setServoPulse(SERVOPINLEFT, 0);
   	setServoPulse(SERVOPINRIGHT, 0);

	/*do something*/
	printf("killing process %d\n",getpid());
	exit(1);

}

void setup(){ 

  delay(1000);
  drawTo(75.2, 47);
  lift(0);

  delay(1000);

}

void loops(){ 

#ifdef CALIBRATION
  // Servohorns will have 90° between movements, parallel to x and y axis
  drawTo(-3, 29.2);
  delay(500);
  drawTo(74.1, 28);
  delay(500);
#else 

    time_t seconds = 0;
    char *ptr;
    struct tm *utc_time = NULL;
    struct tm *local_time = NULL;
	int hours, minutes;

    seconds = time((time_t *)NULL);
    printf("seconds = %ld\n", seconds);
    //utc_time = gmtime(&seconds);
    //printf("UTC hour is   : %0d\n",utc_time->tm_hour);
    local_time = localtime(&seconds);
	hours = local_time->tm_hour;
	minutes = local_time->tm_min;

    printf("Local hour is : %02d\n",local_time->tm_hour);
    printf("Local minute is : %0d\n",local_time->tm_min);
    //ptr = asctime(local_time);
    //printf("Local time is :%s\n",ptr);

    if (minutes != last_min || hours != last_hours)
    {

   		lift(0);
    	number(3, 3, 111, 0.9);
        number(5, 30, hours / 10, 0.9);
        number(19, 30, hours % 10, 0.9);
        number(28, 30, 11, 0.9);
        number(34, 30, minutes / 10, 0.9);
        number(48, 30, minutes % 10, 0.9);

		lift(2);
    	drawTo(74.2, 47.5);
    
		lift(0);

    	setServoPulse(SERVOPINLIFT, 0);
    	setServoPulse(SERVOPINLEFT, 0);
    	setServoPulse(SERVOPINRIGHT, 0);

		last_min = minutes;
		last_hours = hours;
    }

#endif
} 



int main(int argc, char *argv[])
{

	int fd;
	int time=1;
    
	signal(SIGINT, sigint_handler);
	
     /*RPI*/
    wiringPiSetup();
    /*WiringPi GPIO*/
   
	

		// Setup with pinbase 300 and i2c location 0x40
	fd = pca9685Setup(PIN_BASE, 0x40, HERTZ);
    if (fd < 0)
	{
		printf("Error in setup\n");
		return fd;
	}
	// Reset all output
	pca9685PWMReset(fd);

    printf("ok\n");
	setup();
	while(1)
		loops();
	
return 0;

}

